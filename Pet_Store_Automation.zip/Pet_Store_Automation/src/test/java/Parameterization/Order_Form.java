package Parameterization;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Order_Form {

	WebDriver driver;
	
	By CB =By.xpath("//button[contains(text(),'Continue')]");
	
	public Order_Form (WebDriver driver) {
		this.driver=driver;
		
	}

	public void ContinueB () {
		driver.findElement(CB).click();
		
	}
}
	

