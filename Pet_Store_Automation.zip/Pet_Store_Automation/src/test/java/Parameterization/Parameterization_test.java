package Parameterization;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.time.Duration;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import au.com.bytecode.opencsv.CSVReader;


public class Parameterization_test {
	  
	String driverPath = "C:\\Users\\OjusMasson\\Desktop\\Selenium\\WebDrivers\\geckodriver-v0.32.0-win64\\geckodriver.exe";
	
	    
	     WebDriver driver;

      SignUp objsignup;
       Login objlogin;
       Validate_emptycart objvalempty;
       Validate_emptycart1 objvalmessage;
       Search_Pet objsearch;
       Product_ID objpr;
       Item_ID objproduct;
       Print_ItemDetails objPD;
       View_Cart objVC;
       ProceedToCheckout objPTC;
       ProceedToCheckout1 objPTC1;
       Order_Form objclick;
       Order_Form1 objcontinue;
       Validating_Thankyou objVTY;
       DeletingOrder objdlt;
       Delete_OrderID objdltID;
       Final_Delete objfnldlt;
       Final objfnl;
       
	   
	     
	     @BeforeTest


	       public void setup() throws IOException{


	       System.setProperty("webdriver.gecko.driver", driverPath);
	            
	            driver = new FirefoxDriver();


	           driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));


	           driver.get("https://jpetstore.aspectran.com/account/signonForm");
	           
	           driver.manage().window().maximize();
	     }
	           	            
	     @Test
	     
	     public void Test() throws Exception  {
	        
	    	 FileInputStream file = new FileInputStream("C:\\Users\\OjusMasson\\Desktop\\Selenium\\Test Datas\\ProjectPetStore.xlsx");
	    	 XSSFWorkbook workbook = new XSSFWorkbook(file);
	    	 XSSFSheet wbst1 = workbook.getSheetAt(0);
	    	 XSSFCell username;
	    	 XSSFCell password;
	    	/* XSSFCell conpassword;
	    	 XSSFCell fname;
	    	 XSSFCell lname;
	    	 XSSFCell email;
	    	 XSSFCell phone;
	    	 XSSFCell address1;
	    	 XSSFCell address2;
	    	 XSSFCell city;
	    	 XSSFCell state;
	    	 XSSFCell country;
	    	 XSSFCell Zip;
	    		 username =  wbst1.getRow(1).getCell(0);
	    		 password =  wbst1.getRow(1).getCell(1);
	    		 conpassword =  wbst1.getRow(1).getCell(2);
	    		 fname =  wbst1.getRow(1).getCell(3);
	    		 lname =  wbst1.getRow(1).getCell(4);
	    		 email =  wbst1.getRow(1).getCell(5);
	    		 phone =  wbst1.getRow(1).getCell(6);
	    		 address1 =  wbst1.getRow(1).getCell(7);
	    		 address2 =  wbst1.getRow(1).getCell(8);
	    		 city =  wbst1.getRow(1).getCell(9);
	    		 state =  wbst1.getRow(1).getCell(10);
	    		 country =  wbst1.getRow(1).getCell(11);
	    		 Zip =  wbst1.getRow(1).getCell(12);
	    		 objsignup = new SignUp(driver);   
	    		 objsignup.signUpPetStore(username.toString(),password.toString(),conpassword.toString(),fname.toString(),lname.toString(),email.toString(),phone.toString(),address1.toString(),address2.toString(),city.toString(),state.toString(),country.toString(),Zip.toString());
	    	 */
	    	 
	    	 
	    	 
	    	 XSSFCell username1;
	    	 XSSFCell password1;		 
	   
	    	 username =  wbst1.getRow(1).getCell(0);
    		 password =  wbst1.getRow(1).getCell(1);
    		 username1 =  wbst1.getRow(2).getCell(0);
    		 password1 =  wbst1.getRow(2).getCell(1);
	    objlogin = new Login(driver);
        objlogin.LoginPetStore(username.toString(),password.toString());
        objlogin.clickLogin();
        driver.navigate().back();
        objlogin.LoginPetStore(username1.toString(),password1.toString());
        objlogin.clickLogin();
        objlogin.errorpop();
	   
	    objvalempty = new Validate_emptycart(driver);
	    objvalempty.clickLogin();
	    
	    objvalmessage = new Validate_emptycart1(driver);
	    objvalmessage.emptypop();
	    
	    objsearch = new Search_Pet(driver);
	    objsearch.JavaScript();
	    
	    objpr =new Product_ID(driver);
	    objpr.clickproduct();
	    
	    objproduct = new Item_ID(driver);
	    objproduct.clickproductid();
	    
	    objPD = new Print_ItemDetails(driver);
	    objPD.PD1();
	    
	    objVC = new View_Cart(driver);
	    objVC.VC1();
	    
	    objPTC = new ProceedToCheckout(driver);
	    objPTC.PTC();
	    
	    objPTC1 = new ProceedToCheckout1(driver);
	    objPTC1.PTC1();
	    
	    objclick = new Order_Form(driver);
	    objclick.ContinueB();
	    
	    objcontinue = new Order_Form1(driver);
	    objcontinue.ConfirmB();
	    
	    objVTY = new Validating_Thankyou(driver);
	    objVTY.VT1();
	    
	    objdlt = new DeletingOrder(driver);
	    objdlt.Dlt();
	    
	 //   objdltID = new Delete_OrderID(driver);
	 //   objdltID.Dlt1();
	    
	 //   objfnldlt = new Final_Delete(driver);
	 //   objfnldlt.Dlt2();
	    
	    objfnl = new Final(driver);
	    objfnl.Home();
	    
	    
	    	 
	    driver.close();
	     
	     }        
	}


	

