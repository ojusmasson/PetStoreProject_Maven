package Parameterization;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Print_ItemDetails {

	WebDriver driver;
	
 By pd = By.xpath("//td[contains(text(),'Friendly dog from England')]");
 By Atc = By.xpath("//a[@class='button']");
 
     public Print_ItemDetails(WebDriver driver) {
	 this.driver=driver;
 }
 
 public void PD1 () {

	 System.out.println(driver.getCurrentUrl());
	 WebElement ec = driver.findElement(pd);
	 System.out.println(ec.getText());
	 
	 driver.findElement(Atc).click();
	 
 }
}
