package Parameterization;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ProceedToCheckout1 {

	WebDriver driver;
	
	By ProceedTC =By.xpath("//a[contains(text(),'Proceed to Checkout')]");
	
	public ProceedToCheckout1 (WebDriver driver) {
		this.driver=driver;
		
	}

	public void PTC1 () {
		driver.findElement(ProceedTC).click();
		
	}
}


