package Parameterization;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class DeletingOrder {

WebDriver driver;
	
	By delete = By.xpath("//button[@type='button']");
	
	
	public DeletingOrder (WebDriver driver) {
		this.driver=driver;
	}
		
		public void Dlt () {
			
			driver.findElement(delete).click();
			
		}
	
}
