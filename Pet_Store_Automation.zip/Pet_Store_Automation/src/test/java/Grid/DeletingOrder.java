package Grid;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.remote.DesiredCapabilities;


public class DeletingOrder {

WebDriver driver;
	
	By delete = By.xpath("//button[@type='button']");
	
	
	public DeletingOrder (WebDriver driver) {
		this.driver=driver;
	}
		
		public void Dlt () {
			
			driver.findElement(delete).click();
			
		}
	
}

		

	

