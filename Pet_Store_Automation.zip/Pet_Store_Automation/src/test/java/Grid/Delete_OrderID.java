package Grid;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Delete_OrderID {


WebDriver driver;
	
	By deleteID = By.xpath("//a[contains(text(),'22353')]");
	
	
	public Delete_OrderID (WebDriver driver) {
		this.driver=driver;
	}
		
		public void Dlt1 () {
			
			driver.findElement(deleteID).click();
			
		}
	
}
