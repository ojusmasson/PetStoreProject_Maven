package Grid;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

public class Search_Pet {

	WebDriver driver;
	
By search = By.xpath("//form[@action='/catalog/searchProducts']//div[@class='input-group']//input[@type='text']");

	
	public Search_Pet(WebDriver driver){
        this.driver = driver;
}
	public void JavaScript() {
        driver.findElement(search).click();
        JavascriptExecutor js = (JavascriptExecutor)driver;
      js.executeScript("document.getElementsByClassName(\"input-group-field\")[1].value=\"dog\"");
      		js.executeScript("document.getElementsByClassName(\"input-group-field\")[1].value=(\"dog\")");
      js.executeScript("document.getElementsByClassName(\"button\")[1].click()");
	
}
}
