package Grid;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Validate_emptycart1 {

WebDriver driver;
	
	By emptycart = By.xpath("/html/body/section/div[2]/div[2]/div[2]/div[1]/form/table/tbody/tr[2]/td");
	By backtohome = By.xpath("//a[contains(text(),'Return to Main Menu')]");
	
	
	 public Validate_emptycart1(WebDriver driver){
         this.driver = driver;
}
	 
	 public void emptypop() {
   	  WebElement printE = driver.findElement(emptycart);
   	  System.out.println(printE.getText());
   	  
   	  
   	  driver.findElement(backtohome).click();
   	  
	 }
}
