package Grid;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Validate_emptycart {

	WebDriver driver;
	
	By clickcart = By.xpath("//img[@name='img_cart']");
	
	 public Validate_emptycart(WebDriver driver){
         this.driver = driver;
	 }
	 
	  public void clickLogin(){
          driver.findElement(clickcart).click();
}
}
