package Grid;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Final {


WebDriver driver;
	
	By backtohome = By.xpath("//li[@role='none']//a[contains(text(),'JPetStore Demo')]");
	
	
	public Final (WebDriver driver) {
		this.driver=driver;
	}
		
		public void Home () {
			
			driver.findElement(backtohome).click();
	
}
	
}
