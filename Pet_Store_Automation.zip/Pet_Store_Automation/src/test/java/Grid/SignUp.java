package Grid;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class SignUp {

	

		WebDriver driver;
	    
		By SignUp1 = By.linkText("Sign Up");
	      By user_NAME = By.name("username");
	    By New_password = By.name("password");
	    By Confirm_password  =  By.name("repeatedPassword");
	    By First_name =By.name("firstName") ;
	    
	    By Last_name = By.name("lastName");
	    
	    By Email = By.name("email");
		By Phone = By.name("phone");
		By Address_1 = By.name("address1");
		By Address_2   = By.name("address2");
		By City = By.name("city");
		By State = By.name("state");
	    By Zip  =By.name("zip");	
	    By Country = By.name("country");
	    By Enable_MyList = By.xpath("//td[contains(text(),'Enable MyList')]");
	    By Enable_MyBanner = By.xpath("//td[contains(text(),'Enable MyBanner')]");
	    By Save_Account = By.xpath("//button[contains(text(),'Save Account Information')]");

	    public SignUp (WebDriver driver){
	        this.driver = driver;
	        
	        
	    }
	    
	    public void SignUp_Button() {
	    	driver.findElement(SignUp1).click();
	    	
	    }
	    
	    public void username(String strUserName) {
	    	driver.findElement(user_NAME).sendKeys(strUserName);

	    }
	    
	    
	    public void password (String p) {
	    	
	    	driver.findElement(New_password).sendKeys(p);
	    	
	    }
	    public void Confirpassword(String w) {
	    	
	    	driver.findElement(Confirm_password).sendKeys(w);

	    }
	    
	    public void First_name(String r) {
	    	driver.findElement(First_name).sendKeys(r);
	    	
	    }
	    
	    public void Last_name (String t ) {
	    	driver.findElement(Last_name).sendKeys(t);
	    	
	    }
	    
	    public void Email (String y ) {
	    	driver.findElement(Email).sendKeys(y);
	    }
	    
	    
	    public void  Phone  (String u) {
	    	driver.findElement(Phone).sendKeys(u);

	    }
	    
	    
	    public void Address_1  (String i) {
	    	
	    	driver.findElement(Address_1).sendKeys(i);
	    }
	    
	    
	    public void Address_2 (String o) {
	    	driver.findElement(Address_2).sendKeys(o);
	    }
	    
	    
	    public void  City (String x) {
	    	driver.findElement(City).sendKeys(x);
	    }
	    
	    
	    public void state (String a) {
	    	driver.findElement(State).sendKeys(a);	
	    }
	    public void  Zip (String s) {
	    	driver.findElement(Zip).sendKeys(s);
	    }
	    
	    public void Country(String z) {
	    	driver.findElement(Country).sendKeys(z);

	    }
	    
	    
	    public void Enable_MyList() {
	    	driver.findElement(Enable_MyList).click();

	    }
	    
	    
	     public void Enable_MyBanner () {
	    	 driver.findElement(Enable_MyBanner).click(); 
	     }
	     
	     public void Save_Account () {
	    	 driver.findElement(Save_Account).click();
	     }
	    	 
	    	 public void signUpPetStore (String strUserName, String p, String w, String r, String t, String y, String u,String i, String o, String x,String a, String s, String z ) throws InterruptedException {
	    		 
	    		 this.SignUp_Button();
	    		 this.username(strUserName);
	    		 this.password(p);
	    		 this.Confirpassword(w);
	    		 this.First_name(r);
	    		 this.Last_name(t);
	    		 this.Email(y);
	    		 this.Phone(u);
	    		 this.Address_1(i);
	    		 this.Address_2(o);
	    		 this.City(x);
	    		 this.state(a);
	    		 this.Zip(s);
	    		 this.Country(z);
	    		 this.Enable_MyList();
	    		 this.Enable_MyBanner();
	    		 this.Save_Account();
	    		 
	    		 Thread.sleep(3000);
	     }
	    	 
	     
	     
	     
	     
}
