package Repositry;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Grid.Login;


public class Repositry {
	  
	 
	    
	String driverPath = "C:\\Users\\OjusMasson\\Desktop\\Selenium\\WebDrivers\\geckodriver-v0.32.0-win64\\geckodriver.exe";
	
	WebDriver driver;
	     Properties prop;


       
	   
	     
	     @Test


	       public void setup() throws Exception{

	    	 System.setProperty("webdriver.gecko.driver", driverPath);	         
	    	 
	    	 driver = new FirefoxDriver();
	    	 
	    	 File src= new File("C:\\Users\\OjusMasson\\Desktop\\Selenium\\SeleniumProjects\\JavaBasics\\ProjectPetStore\\Pet_Store_Automation\\SignupRepositry\\signup.properties");
	         FileInputStream fis = new FileInputStream(src);    
	      // Load the properties File
	         prop = new Properties();
	         prop.load(fis);
	         
	         


	           driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

	           driver.get("https://jpetstore.aspectran.com/account/newAccountForm");
	           
	           driver.manage().window().maximize();
	           
	           
	          // driver.findElement(By.xpath(prop.getProperty("SignupButton"))).click();
	           driver.findElement(By.xpath(prop.getProperty("useridxpath"))).sendKeys("prtcomp_99");
	           driver.findElement(By.xpath(prop.getProperty("passwordxpath"))).sendKeys("pet@1234");
		    	driver.findElement(By.xpath(prop.getProperty("conpasswordxpath"))).sendKeys("pet@1234");
		    	driver.findElement(By.xpath(prop.getProperty("FirstNamexpath"))).sendKeys("pet");
		    	driver.findElement(By.xpath(prop.getProperty("LastNamexpath"))).sendKeys("master");
		    	driver.findElement(By.xpath(prop.getProperty("Emailxpath"))).sendKeys("pet@gmail.com");
		    	driver.findElement(By.xpath(prop.getProperty("Phonexpath"))).sendKeys("8934567891");
		    	driver.findElement(By.xpath(prop.getProperty("address1xpath"))).sendKeys("Hyderabad");
		    	driver.findElement(By.xpath(prop.getProperty("address2xpath"))).sendKeys("Ameerpet");
		    	driver.findElement(By.xpath(prop.getProperty("cityxpath"))).sendKeys("Hyderabad");
		    	driver.findElement(By.xpath(prop.getProperty("statexpath"))).sendKeys("Telengana");
		    	driver.findElement(By.xpath(prop.getProperty("zipxpath"))).sendKeys("500038");
		    	driver.findElement(By.xpath(prop.getProperty("countryxpath"))).sendKeys("India");
		    	driver.findElement(By.xpath(prop.getProperty("Enablemylistxpath"))).click();
		    	driver.findElement(By.xpath(prop.getProperty("Enablemybannerxpath"))).click();
		        driver.findElement(By.xpath(prop.getProperty("saveaccount"))).click();



      
	     }
	     
	           
	            
	   

}

	

