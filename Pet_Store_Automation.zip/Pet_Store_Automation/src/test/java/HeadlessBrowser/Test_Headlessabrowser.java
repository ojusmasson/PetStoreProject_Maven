package HeadlessBrowser;

import java.io.File;
import java.time.Duration;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.io.FileHandler;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Grid.Delete_OrderID;
import Grid.DeletingOrder;
import Grid.Final;
import Grid.Final_Delete;
import Grid.Item_ID;
import Grid.Login;
import Grid.Order_Form;
import Grid.Order_Form1;
import Grid.Print_ItemDetails;
import Grid.ProceedToCheckout;
import Grid.ProceedToCheckout1;
import Grid.Product_ID;
import Grid.Search_Pet;
import Grid.SignUp;
import Grid.Validate_emptycart;
import Grid.Validate_emptycart1;
import Grid.Validating_Thankyou;
import Grid.View_Cart;


public class Test_Headlessabrowser {
	  
	String driverPath = "C:\\Users\\OjusMasson\\Desktop\\Selenium\\WebDrivers\\geckodriver-v0.32.0-win64\\geckodriver.exe";
	
	    
	     WebDriver driver;

      SignUp objsignup;
       Login objlogin;
       Validate_emptycart objvalempty;
       Validate_emptycart1 objvalmessage;
       Search_Pet objsearch;
       Product_ID objpr;
       Item_ID objproduct;
       Print_ItemDetails objPD;
       View_Cart objVC;
       ProceedToCheckout objPTC;
       ProceedToCheckout1 objPTC1;
       Order_Form objclick;
       Order_Form1 objcontinue;
       Validating_Thankyou objVTY;
       DeletingOrder objdlt;
       Delete_OrderID objdltID;
       Final_Delete objfnldlt;
       Final objfnl;
       
	   
	     
	     @BeforeTest


	       public void setup(){


	       System.setProperty("webdriver.gecko.driver", driverPath);
	            
	       FirefoxOptions options = new FirefoxOptions();
	        options.setHeadless(true);
	       
	            driver = new FirefoxDriver(options);


	           driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));


	           driver.get("https://jpetstore.aspectran.com/account/signonForm");
	           
	           driver.manage().window().maximize();
	     }
	     
	           
	            
	     @Test
	     
	     public void Test() {
	        
	     //  objsignup = new SignUp(driver);   
	    //   objsignup.signUpPetStore("prtcomp_99","pet@1234","pet@1234","pet", "master", "pet@gmail.com", "8934567891", "Hyderabad", "Ameerpet", "Hyderabad", "Telengana", "500038", "India");
	     
	    objlogin = new Login(driver);
        objlogin.LoginPetStore("prtcomp_99","pet@1234");
        driver.navigate().back();
        objlogin.LoginPetStore("prtcomp_99","");
        objlogin.errorpop();
	   
	    objvalempty = new Validate_emptycart(driver);
	    objvalempty.clickLogin();
	    
	    objvalmessage = new Validate_emptycart1(driver);
	    objvalmessage.emptypop();
	    
	    objsearch = new Search_Pet(driver);
	    objsearch.JavaScript();
	    
	    objpr =new Product_ID(driver);
	    objpr.clickproduct();
	    
	    objproduct = new Item_ID(driver);
	    objproduct.clickproductid();
	    
	    objPD = new Print_ItemDetails(driver);
	    objPD.PD1();
	    
	    objVC = new View_Cart(driver);
	    objVC.VC1();
	    
	    objPTC = new ProceedToCheckout(driver);
	    objPTC.PTC();
	    
	    objPTC1 = new ProceedToCheckout1(driver);
	    objPTC1.PTC1();
	    
	    objclick = new Order_Form(driver);
	    objclick.ContinueB();
	    
	    objcontinue = new Order_Form1(driver);
	    objcontinue.ConfirmB();
	    
	    objVTY = new Validating_Thankyou(driver);
	    objVTY.VT1();
	    
	    objdlt = new DeletingOrder(driver);
	    objdlt.Dlt();
	    
	 //   objdltID = new Delete_OrderID(driver);
	 //   objdltID.Dlt1();
	    
	 //   objfnldlt = new Final_Delete(driver);
	 //   objfnldlt.Dlt2();
	    
	    objfnl = new Final(driver);
	    objfnl.Home();
	    
	    try {
            //Convert web driver object to TakeScreenshot
            //Call getScreenshotAs method to create image file
                  File src= ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
                  //FileUtils.copyFile(src, new File(".screenshots.jpeg"));
                  FileHandler.copy(src, new File("C:\\Users\\OjusMasson\\Desktop\\screenshot\\screengrid.jpg"));
              }
              
              catch(Exception e){
                  //if it fails to take screenshot then this block will execute
                  System.out.println("Failure to take screenshot "+e);
              }
	    
	    	 
	    driver.close();
	     
	            
	}
}

	

