package HeadlessBrowser;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Product_ID {

	WebDriver driver;
	
	By clickpr = By.xpath("//a[contains(text(),'K9-BD-01')]");

		
		public Product_ID(WebDriver driver){
	        this.driver = driver;
	}
	
		public void clickproduct() {
			driver.findElement(clickpr).click();
		}
}
