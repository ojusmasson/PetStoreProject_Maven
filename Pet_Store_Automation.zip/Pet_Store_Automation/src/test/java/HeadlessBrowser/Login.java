package HeadlessBrowser;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Login {
   
	WebDriver driver;
	
	By username = By.xpath("//label[contains(text(),'Username:')]//input[@type='text']");
	By Password = By.xpath("//input[@type='password']");
    By login = By.xpath("//button[normalize-space()='Login']");
    By error = By.xpath("//div[@class='panel failed']");
     
    
      public Login(WebDriver driver){
            this.driver = driver;
        }
      
      public void clickusername() {
    	  driver.findElement(username).clear();
      }
      
      public void entrusername(String strusername) {
    	  driver.findElement(username).sendKeys(strusername);
      }
      
      public void clickpassword() {
    	  driver.findElement(Password).clear();
      }
      public void entrpassword(String strpassword) {
    	  driver.findElement(Password).sendKeys(strpassword);
    	  
      }
      
      public void clickLogin(){
            driver.findElement(login).click();
            }
     
         public void errorpop() {
    	 WebElement printE = driver.findElement(error);
    	  System.out.println(printE.getText());
     }

	public void LoginPetStore(String strusername, String strpassword) {
		
	  this.clickusername();
   	  this.entrusername(strusername);
   	  this.clickpassword();
   	  this.entrpassword(strpassword);
   	  this.clickLogin();
		
	}


}

