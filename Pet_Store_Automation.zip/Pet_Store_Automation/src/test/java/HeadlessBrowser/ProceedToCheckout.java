package HeadlessBrowser;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ProceedToCheckout {
	
	WebDriver driver;
	
	By carticon =By.name("img_cart");
	
	public ProceedToCheckout (WebDriver driver) {
		this.driver=driver;
		
	}

	public void PTC () {
		driver.findElement(carticon).click();
		
	}
}
