package HeadlessBrowser;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Final_Delete {

WebDriver driver;
	
	By deleteorder = By.xpath("//button[@type='button']");
	
	
	public Final_Delete (WebDriver driver) {
		this.driver=driver;
	}
		
		public void Dlt2 () {
			
			driver.findElement(deleteorder).click();
	
}
}