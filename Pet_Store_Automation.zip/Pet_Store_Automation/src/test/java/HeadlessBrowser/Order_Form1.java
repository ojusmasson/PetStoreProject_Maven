package HeadlessBrowser;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Order_Form1 {

	WebDriver driver;
	
	By CB1 =By.xpath("//button[contains(text(),'Confirm')]");
	
	public Order_Form1 (WebDriver driver) {
		this.driver=driver;
		
	}

	public void ConfirmB () {
		driver.findElement(CB1).click();
		
	
}
}
