package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Validating_Thankyou {

	WebDriver driver;
	
	By VT = By.xpath("//p[contains(text(),'Thank you, your order has been submitted.')]");
	
	
	public Validating_Thankyou (WebDriver driver) {
		this.driver=driver;
	}
		
		public void VT1 () {
			
			WebElement X = driver.findElement(VT);
			System.out.println(X.getText());
			
		}
	
}
