package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Item_ID {
WebDriver driver;
	
	By clickproduct = By.xpath("//a[contains(text(),'EST-6')]");

		
		public Item_ID(WebDriver driver){
	        this.driver = driver;
	}
	
		public void clickproductid() {
			driver.findElement(clickproduct).click();
		}
}
