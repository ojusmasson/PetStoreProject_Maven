package POM;

import java.time.Duration;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Validate_emptycart {

	WebDriver driver;

	By clickcart = By.xpath("//img[@name='img_cart']");
	
	 public Validate_emptycart(WebDriver driver){
         this.driver = driver;
	 }
	 
	 public void regularexpression() {
		 
		 String Title = driver.getTitle();
		    System.out.println(Title);
		    System.out.println(Pattern.matches("[A-Z|a-z|\\W]+", Title));
		    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	 }
	 
	  public void clickLogin(){
          driver.findElement(clickcart).click();
}
}
