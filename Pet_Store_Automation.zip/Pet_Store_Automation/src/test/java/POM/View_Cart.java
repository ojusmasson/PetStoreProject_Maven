package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class View_Cart {

	
	WebDriver driver;

	 By Chng = By.xpath("//input[@type='number']");
	 By Updt = By.xpath("//button[contains(text(),'Update Cart')]");	
	By Ret = By.xpath("//a[contains(text(),'Return to Main Menu')]");

	public View_Cart (WebDriver driver) {
		this.driver=driver; 
	}
	 
	
	public void VC1 () {
		
		driver.findElement(Chng).clear();
		driver.findElement(Chng).sendKeys("3");
		driver.findElement(Updt).click();
		driver.findElement(Ret).click();
	}
	}

	

