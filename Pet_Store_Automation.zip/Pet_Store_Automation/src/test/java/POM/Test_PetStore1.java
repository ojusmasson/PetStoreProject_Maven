

package POM;

import java.time.Duration;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Grid.Login;


public class Test_PetStore1 {
	  
	String driverPath = "C:\\Users\\OjusMasson\\Desktop\\Selenium\\WebDrivers\\geckodriver-v0.32.0-win64\\geckodriver.exe";
	
	    
	     WebDriver driver;

      SignUp objsignup;
       Login objlogin;
       Validate_emptycart objvalempty;
       Validate_emptycart1 objvalmessage;
       Search_Pet objsearch;
       Product_ID objpr;
       Item_ID objproduct;
       Print_ItemDetails objPD;
       View_Cart objVC;
       ProceedToCheckout objPTC;
       ProceedToCheckout1 objPTC1;
       Order_Form objclick;
       Order_Form1 objcontinue;
       Validating_Thankyou objVTY;
       DeletingOrder objdlt;
       Delete_OrderID objdltID;
       Final_Delete objfnldlt;
       Final objfnl;
       
	   
	     
	     @BeforeTest


	       public void setup(){


	       System.setProperty("webdriver.gecko.driver", driverPath);
	            
	            driver = new FirefoxDriver();


	           driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));


	           driver.get("https://jpetstore.aspectran.com/account/signonForm");
	           
	           driver.manage().window().maximize();
	     }
	     
	           
	            
	     @Test
	     
	     public void Test() throws InterruptedException {
	        
	     //  objsignup = new SignUp(driver);   
	    //   objsignup.signUpPetStore("prtcomp_99","pet@1234","pet@1234","pet", "master", "pet@gmail.com", "8934567891", "Hyderabad", "Ameerpet", "Hyderabad", "Telengana", "500038", "India");
	     
	    	 objlogin = new Login(driver);
	         objlogin.LoginPetStore("prtcomp_99","pet@1234");
	         driver.navigate().back();
	         objlogin.LoginPetStore("prtcomp_99","");
	         objlogin.errorpop();
	   
	    objvalempty = new Validate_emptycart(driver);
	    objvalempty.clickLogin();
	    objvalempty.regularexpression();
	    
	    objvalmessage = new Validate_emptycart1(driver);
	    objvalmessage.emptypop();
	    
	    objsearch = new Search_Pet(driver);
	    objsearch.JavaScript();
	    
	    objpr =new Product_ID(driver);
	    objpr.clickproduct();
	    
	    objproduct = new Item_ID(driver);
	    objproduct.clickproductid();
	    
	    objPD = new Print_ItemDetails(driver);
	    objPD.PD1();
	    
	    objVC = new View_Cart(driver);
	    objVC.VC1();
	    
	    objPTC = new ProceedToCheckout(driver);
	    objPTC.PTC();
	    
	    objPTC1 = new ProceedToCheckout1(driver);
	    objPTC1.PTC1();
	    
	    objclick = new Order_Form(driver);
	    objclick.ContinueB();
	    
	    objcontinue = new Order_Form1(driver);
	    objcontinue.ConfirmB();
	    
	    objVTY = new Validating_Thankyou(driver);
	    objVTY.VT1();
	    
	    objdlt = new DeletingOrder(driver);
	    objdlt.Dlt();
	    
	 //   objdltID = new Delete_OrderID(driver);
	 //   objdltID.Dlt1();
	    
	 //   objfnldlt = new Final_Delete(driver);
	 //   objfnldlt.Dlt2();
	    
	    objfnl = new Final(driver);
	    objfnl.Home();
	    
	    
	    	 
	    driver.close();
	     
	            
	}
}

	

